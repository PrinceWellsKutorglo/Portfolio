# Personal Portfolio

### Light Mode
![Portfolio Screenshot-Light Mode](/assets/img/portfolio.png)

### Dark Mode
![Portfolio Screenshot-Dark Mode](/assets/img/dark_portfolio.png)

This is a simple & responsive personal portfolio that showcases one's but not limited to experiences, education, projects, certifications, profile and technologies. This project is Open Sourced & therefore feel free to clone the repo and create your own portfolio and edit it to your liking. Enjoy! :sparkles: :tada: :octocat:

Done with :heart: by @kutorgloPrinceWells